function formInfo() {

    var arrival = document.getElementById('arrival').value
    var departure = document.getElementById('departure').value
    var persons = document.getElementById('persons').value
    var rooms = document.getElementById('rooms').value

    if (arrival == "" || departure == "") {
        alert('Empty field')    
    }
    else if (arrival === departure) {
        alert('Please enter correct date')
    }
    else {
        localStorage.setItem('arrival',arrival)
        localStorage.setItem('departure',departure)
        localStorage.setItem('persons',persons)
        localStorage.setItem('rooms',rooms)
        document.getElementById('confirm').innerHTML = 'Done' + alert("created successfully")
    }
}
